# Installation and Setup

Download this repo to your local machine. Navigate to the root folder and, use your Terminal App to run the commands below.

1. Run the command `npm install` to install node_modules
2. Run the command `npm run start` to start the app
3. Run the command `npm run json:server` to start the character database